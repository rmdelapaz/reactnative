// Sizes in density-independent pixels: plain numbers, no units
export const spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
} as const;

export const radius = {
  card: 12,
} as const;
